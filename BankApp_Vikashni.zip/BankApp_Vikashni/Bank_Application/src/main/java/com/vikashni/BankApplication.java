package com.vikashni;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankApp_Vikashni {

	public static void main(String[] args) {
		SpringApplication.run(BankApp_Vikashni.class, args);
	}

}
